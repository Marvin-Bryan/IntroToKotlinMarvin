package com.example.cobaretrofit

import com.google.gson.annotations.SerializedName

data class PostResponse(
    val id: Int,
    val email: String?,
    val first_name: String?,
    val last_name: String?,
    val avatar: String?
)
