package com.example.cobaretrofit

import retrofit2.Call
import retrofit2.http.GET

interface Api {
    @GET("api/users?page=2")
    fun getList(): Call<ArrayList<PostResponse>>
}